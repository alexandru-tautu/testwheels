from .fwa import *
from .dem import extract_dem
from . import util

tables, aliases = util.get_shortcuts()


__version__ = "0.0.2"
